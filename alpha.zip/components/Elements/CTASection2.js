import ImgLoader from '../Image'




export default function CTAsection2() {

    return (
        <div className='faq'>
             <div className="container">
            <div className="faq-bottom">
                <h4>Want to learn more?</h4>
                <p>Can’t find the answer you’re looking for? Please get in touch</p>
                <a href="/contact"><button className="btn">CONTACT NOW</button></a>
            </div>
            </div>
        </div>

    )

}