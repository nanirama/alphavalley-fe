
export default function CTAsection1() {

    return (
        <div className='contact-section'>
             <div className="container">
   <div className="contact-box">
      <h4>Want to learn more?</h4>
      <p>Can’t find the answer you’re looking for? Please get in touch</p>
      <a href="/contact"><button className="btn">CONTACT NOW</button></a>
   </div>
</div>

        </div>

    )

}