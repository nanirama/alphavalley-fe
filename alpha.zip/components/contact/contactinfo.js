import ImgLoader from '../Image'

import Emailimg from "../../assets/images/email.png"

import Locationimg from "../../assets/images/location.png"

import Phoneimg from "../../assets/images/phone.png"

export default function Contactinfo() {
    return (
        <>
            <div class="heading">
                <span>Contact us</span>
                <h1>We'd love to hear from you</h1>
                <p>Our friendly team is always here to chat.</p>
            </div>
            <div class="info-section row">
                <div class="content-box col-lg-4 col-md-6 col-sm-12 col-12">
                    <ImgLoader src={Emailimg} alt="Cards" />
                    <h5 class="title">Email</h5>
                    <p class="description">Our friendly team is here to help.</p>
                    <p class="content">hello@alphavalley.co</p>
                </div>
                <div class="content-box col-lg-4 col-md-6 col-sm-12 col-12">
                    <ImgLoader src={Locationimg} alt="Cards" />
                    <h5 class="title">Office</h5>
                    <p class="description">Come say hello at our office HQ.</p>
                    <p class="content">101, Fortune House, Baner Pashan Link Road, Pune, India</p>
                </div>
                <div class="content-box col-lg-4 col-md-12 col-sm-12 col-12">
                    <ImgLoader src={Phoneimg} alt="Cards" />
                    <h5 class="title">Phone</h5>
                    <p class="description">Mon-Fri from 8am to 5pm.</p>
                    <p class="content">+1 (555) 000-0000</p>
                </div>
            </div>
        </>
    )
}