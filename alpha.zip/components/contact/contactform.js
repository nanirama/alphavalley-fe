

import React from "react";
import { useForm } from "react-hook-form";
import { useState, Controller } from "react";




export default function Contactform() {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [subject, setSubject] = useState("");
    const [message, setMessage] = useState("");

    const { register, handleSubmit, watch, formState: { errors } } = useForm();
    const onSubmit = data => console.log(data);

    return (
        <>
            
                    <div class="contact-us-form">
                        <span>Contact us</span>
                        <h2>Get in touch</h2>
                        <p>We’d love to hear from you. Please fill out this form.</p>
                        <div class="form-box row">
                            <div class="col-lg-6 col-md-9 col-sm-12 col-12">

                                <form onSubmit={handleSubmit(onSubmit)}
                                    action="#"
                                    method="POST"
                                    className="mt-6 grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-8"
                                >
                                    <div className='d-flex flex-direction-row justify-content-between gap-4'>
                                        <div>
                                            <label
                                                htmlFor="first-name"
                                                className="block text-sm font-medium text-warm-gray-900"
                                            >
                                                First name
                                            </label>
                                            <div className="mt-1">
                                                <input
                                                    {...register("firstName", { required: true })}
                                                    type="text"
                                                    name="first-name"
                                                    id="first-name"
                                                    autoComplete="given-name"
                                                    placeholder='First name'
                                                    className={`form-control ${errors.firstName ? 'is-invalid px-4 block w-full shadow-sm text-warm-gray-900 border-red-500 border rounded-md' : 'py-2 px-4 block w-full shadow-sm text-warm-gray-900 focus:ring-teal-500 focus:border-teal-500 border-warm-gray-300 rounded-md'}`}
                                                    onChange={(e) => setFirstName(e.target.value)}
                                                    value={firstName}

                                                />

                                                {errors.firstName && <p className="error text-red-500">This field is required.</p>}
                                            </div>
                                        </div>
                                        <div>
                                            <label
                                                htmlFor="last-name"
                                                className="block text-sm font-medium text-warm-gray-900"
                                            >
                                                Last name
                                            </label>
                                            <div className="mt-1">
                                                <input
                                                    {...register("lastname", { required: true })}

                                                    type="text"
                                                    name="last-name"
                                                    id="last-name"
                                                    autoComplete="family-name"
                                                    placeholder='Last name'
                                                    className={`form-control ${errors.lastname ? 'is-invalid px-4 block w-full shadow-sm text-warm-gray-900 border-red-500 border rounded-md' : 'py-2 px-4 block w-full shadow-sm text-warm-gray-900 focus:ring-teal-500 focus:border-teal-500 border-warm-gray-300 rounded-md'}`}
                                                    onChange={(e) => setLastName(e.target.value)}

                                                    value={lastName}
                                                />
                                                {errors.lastname && <p className="error text-red-500">This field is required.</p>}

                                            </div>
                                        </div>
                                    </div>

                                    <div className='mt-3'>
                                        <label
                                            htmlFor="email"
                                            className="block text-sm font-medium text-warm-gray-900"
                                        >
                                            Email
                                        </label>
                                        <div className="mt-1">
                                            <input
                                                {...register("email", { required: true })}
                                                id="email"
                                                name="email"
                                                type="email"
                                                autoComplete="email"
                                                placeholder='you@compnay.com'
                                                className={`form-control ${errors.email ? 'is-invalid px-4 block w-full shadow-sm text-warm-gray-900 border-red-500 border rounded-md' : 'py-2 px-4 block w-full shadow-sm text-warm-gray-900 focus:ring-teal-500 focus:border-teal-500 border-warm-gray-300 rounded-md'}`}
                                                onChange={(e) => setEmail(e.target.value)}
                                                value={email}
                                            />
                                            {errors.email && <p className="error text-red-500">This field is required.</p>}
                                        </div>
                                    </div>

                                    <div className='mt-3'>
                                        <div className="flex justify-between">
                                            <label
                                                htmlFor="phone"
                                                className="block text-sm font-medium text-warm-gray-900"
                                            >
                                                Phone number
                                            </label>

                                        </div>
                                        <div className="mt-1">
                                            <div className='d-flex flex-direction-row is-invalid px-4 block w-full shadow-sm text-warm-gray-900 border-red-500 border rounded-md'>
                                                <select {...register("US")} className="border-0">
                                                    <option value="US">US</option>
                                                    <option value="India">India</option>
                                                    <option value="UK">UK</option>
                                                    <option value="AUS">AUS</option>
                                                </select>
                                                <input
                                                    {...register("phone", { required: true })}
                                                    id="phone"
                                                    name="phone"
                                                    type="phone"
                                                    autoComplete="phone"
                                                    placeholder='+1 (555) 000-0000'
                                                    className='is-invalid border-0 px-4 block w-full text-warm-gray-900 rounded-md : py-2 px-4 text-warm-gray-900  rounded-md'
                                                    onChange={(e) => setPhone(e.target.value)}
                                                    value={phone}
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="sm:col-span-2 mt-3">
                                        <div className="flex justify-between">
                                            <label
                                                htmlFor="message"
                                                className="block text-sm font-medium text-warm-gray-900"
                                            >
                                                Message
                                            </label>

                                        </div>
                                        <div className="mt-1">
                                            <textarea
                                                id="message"
                                                name="message"
                                                rows={4}
                                                className="py-3 px-4 block w-full shadow-sm text-warm-gray-900 focus:ring-teal-500 focus:border-teal-500 border border-warm-gray-300 rounded-md"
                                                aria-describedby="message-max"
                                                // defaultValue={""}
                                                onChange={(e) => setMessage(e.target.value)}
                                                value={message}
                                                placeholder='Leave us a message...'
                                            />
                                        </div>
                                        <div class="form-check mt-2">
                                            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                            <label class="form-check-label" for="flexCheckDefault">
                                                You agree to our friendly <a href="#">privacy policy</a>.
                                            </label>
                                        </div>
                                    </div>
                                    <div className="sm:col-span-2 sm:flex sm:justify-end">
                                        <button
                                            type="submit"
                                            className="formsubmit"
                                            onClick={handleSubmit}
                                        >
                                            Send message
                                        </button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                
                   
                
        </>

    )

}