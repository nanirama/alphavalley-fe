import Layout from "../../components/layout"

import CaseStudiessection from "../../components/Elements/CaseStudies"



export default function CaseStudiesPage() {
    return (
        <Layout>
             <div className='home-usa blogsingle'>
                    <CaseStudiessection />
                </div>
        </Layout>
    )
}