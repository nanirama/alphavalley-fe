import Layout from "../components/layout"
import Seo from '../components/seo'

import Herosection from "../components/financial-modeling/herosection"
import StartupSection from "../components/financial-modeling/Startupsection"
import Investerdeck from "../components/financial-modeling/Investerdeck"
import OurProcess from "../components/financial-modeling/Ourprocess"
import StatSection from "../components/financial-modeling/Statsection"
import CaseStudiessection from "../components/Elements/CaseStudies"
import Alumnussection from "../components/Pricing/alumnussection"
import TestimonialsectionPitch from "../components/Pitchdeck/Testimonial"
import Worksection from "../components/Pitchdeck/WorkSection"
import FAQsection from '../components/Elements/FaqSection'
import { fetchAPI } from "../lib/api";

    export default function Pitchdeck({data}) {
    const { MetaData, testimonies, faqs } = data.attributes
    console.log('data.attributes',testimonies.data)
    return (
        <Layout>
              <Seo seo={MetaData[0]}/>
            <div class="pitch-deck">
                <Herosection />
                <StartupSection />
                <Investerdeck />
                <OurProcess />
                <StatSection />
                <div className='home-usa'>
                <CaseStudiessection />
                <Alumnussection />
                <TestimonialsectionPitch data={testimonies.data} />
                <Worksection />
                <FAQsection data={faqs.data} />
                </div>
            </div>
          
        </Layout>

    )

}

export async function getStaticProps() {
    const pageData = await fetchAPI("/api/display-pages?filters[slug][$eq]=pitch-deck&populate=*");
    return {
        props: {
        data: pageData.data[0]
        },
        revalidate: 1,
    };
}