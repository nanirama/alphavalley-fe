import Layout from "../components/layout"
import Seo from '../components/seo'

import Contactform from "../components/contact/contactform"
import Contactinfo from "../components/contact/contactinfo"

export default function Contact({ }) {
    return (
        <Layout>
            <div class="contact-us">
                <div class="container">
                    <Contactform />
                    <Contactinfo />
                </div>
            </div>

        </Layout>
    )
}